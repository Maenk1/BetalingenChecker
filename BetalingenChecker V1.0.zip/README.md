# BetalingenChecker
Een hele simpele pythonapplicatie die op basis van excels checkt of een lid al betaald heeft

## Hoe gebruik je BetalingenChecker
1. Ga naar de BetalingenChecker map
2. open het bestand `inputdata.xlsx`
3. geef onder 'Evenement (of varianten op namen)' het naam van je evenement in en varianten (bv. bierfiets, bier fiets, fietsen +20,..) 
4. Onder 'mensen die moetne betalen' en 'bedrag' haal je uit je afrekening de namen (alleen voornaam is meestal OK) & save
5. Exporteer de overschrijvingen uit KBC touch (https://www.kbc.be/ondernemen/nl/product/betalen-en-betaald-worden/rekeninginformatie/rekeningafschriften.html#:~:text=In%20KBC%20Touch,-Zo%20werkt%20het&text=Klik%20bovenaan%20op%20Rekeningafschriften%2C%20en,je%20bestandsformaat%20(PDF%20of%20CSV))
6. open dit bestand in excel -> Bestand -> Opslaan als.. -> Bladeren -> bestandsnaam: kbcdata opslaan als: Excel-werkmap -> sla op in de BetalingChecker map.
OPGELET: als het bestand een foute naam of indeling heeft zal dit NIET werken!
7. Open de folder in VSCode en run het script





# TO-DO implementaties
- bedrag wordt gecontroleerd
- automatisch berichtjes schrijven naar mensen
- controle bedrag - OK
- checkt ook of naam in mededeling zit
- foutencontrole 
- uploaden van excel bestanden 
- deftige UI
- deftig inzetten voor productie (incl faq maken en documenteren)
